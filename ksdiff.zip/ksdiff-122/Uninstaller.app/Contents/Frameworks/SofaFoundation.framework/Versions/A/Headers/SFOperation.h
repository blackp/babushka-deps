//
//  SFOperation.h
//  SofaFoundation
//
//  Created by Jonathan on 05/05/2010.
//  Copyright 2010 Sofa BV. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SofaFoundation/SofaFoundationMacros.h>

@interface SFOperation : NSOperation 

@end
