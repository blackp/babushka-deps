//
//  SFCLIToken.h
//  SofaFoundation
//
//  Created by Jonathan on 05/01/2011.
//  Copyright 2011 Sofa. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SFCLIToken : NSObject {

}

@end
