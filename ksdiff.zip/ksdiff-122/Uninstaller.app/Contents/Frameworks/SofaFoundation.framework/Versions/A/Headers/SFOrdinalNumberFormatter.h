//
//  SFOrdinalNumberFormatter.h
//  SofaFoundation
//
//  Created by Jonathan Dann on 04/01/2010.
//  Copyright 2010 Sofa BV. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SFOrdinalNumberFormatter : NSFormatter {
	@private
}

@end
